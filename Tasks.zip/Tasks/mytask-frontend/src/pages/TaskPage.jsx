import React from 'react'
import Tasks from "../components/Tasks/Tasks"

export default function TaskPage() {
  return (
    <div><Tasks/></div>
  )
}
