import React from 'react';

function AllTasks({ tasks }) {
  return (
    <div className="w-full">
      <h2 className="text-2xl font-bold my-3 mx-2 text-center lg:text-left">Your Tasks</h2>
      <ul className="flex flex-wrap gap-4 justify-center md:justify-start lg:justify-start m-2">
        {tasks.map((task, index) => (
          <li
            key={index}
            className="bg-white p-4 w-full sm:w-full md:w-[48%] lg:w-[48%] rounded-lg shadow-md"
          >
            <h3 className="text-lg font-semibold mb-2">{task.title}</h3>
            <p className="text-gray-700 mb-2">{task.description}</p>
            <p className="text-gray-500 text-sm">Due Date: {task.dueDate}</p>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default React.memo(AllTasks);
