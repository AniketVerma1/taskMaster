import React from 'react'

const ErrorComponent = () => {
  return (
    <div>Something went wrong !!</div>
  )
}

export default ErrorComponent